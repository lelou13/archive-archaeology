<? echo '<p class="tiny" align = center>Currently using '.METHOD.'</p>'; ?>
</body>
</html>
