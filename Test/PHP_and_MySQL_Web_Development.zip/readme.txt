PHP and MySQL Web Development usage notes
-----------------------------------------

The book companion CD-ROM for PHP and MySQL Web Development
utilizes an HTML interface for the contents. This interface
can be accessed by double-clicking on start.html.

The software on this CD-ROM is separated out by platform
within the respective software directory.

The electronic version of this book can be accessed in the
ebooks directory in Adobe's Portable Document Format (PDF).
If you do not have the Adobe Acrobat Reader installed, you
may install the Linux or Windows version from the CD-ROM in
the appropriate platform directory.

If you have any problems with the media, you can contact our
support department via the web at:

http://www.samspublishing.com/about/contact_us/index.asp